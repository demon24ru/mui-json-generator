<h2 align="center">Material-UIをサポートする</h2>

Material-UIはMITライセンスのオープンソースプロジェクトです。 以下の素晴らしい[サポーターたち](/discover-more/backers/)の支援のおかげで、継続的な開発が完全に可能になった独立したプロジェクトです。

### ゴールドサポーター

ゴールドスポンサーは、毎月500ドル以上をMaterial-UIに約束してくれた方々です。

[パトロン](https://www.patreon.com/oliviertassinari)によるものです。

<p style="display: flex; justify-content: center;">
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="creative-tim" href="https://www.creative-tim.com/?partner=104080" rel="noopener nofollow" target="_blank" style="margin-right: 16px;"><img width="126" src="https://github.com/creativetimofficial.png?size=126" alt="creative-tim" title="プレミアムテーマ"></a>
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="tidelift" href="https://tidelift.com/subscription/pkg/npm-material-ui?utm_source=material_ui&utm_medium=referral&utm_campaign=homepage" rel="noopener nofollow" target="_blank" style="margin-right: 16px;"><img width="96" src="https://github.com/tidelift.png?size=96" alt="タイドリフト" title="プロフェッショナルサポートのMaterial-UIを受け取る"></a>
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="bitsrc" href="https://bit.dev" rel="noopener nofollow" target="_blank" style="margin-right: 16px;"><img width="96" src="https://github.com/teambit.png?size=96" alt="bitsrc" title="コードをシェアする最も早い方法"></a>
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="blokt" href="https://blokt.com/" rel="noopener nofollow" target="_blank" style="margin-right: 16px;"><img width="96" src="https://material-ui.com/static/images/blokt.jpg" alt="ブロークト" title="主要な暗号通貨ニュース"></a>
</p>

[OpenCollective](https://opencollective.com/material-ui)によるものです。

<p style="display: flex; justify-content: center; flex-wrap: wrap;">
  <a data-ga-event-category="sponsors" data-ga-event-action="logo" data-ga-event-label="callemall" href="https://www.call-em-all.com" rel="noopener nofollow" target="_blank" style="margin-right: 16px;">
    <img src="https://images.opencollective.com/proxy/images?src=https%3A%2F%2Fopencollective-production.s3-us-west-1.amazonaws.com%2Ff4053300-e0ea-11e7-acf0-0fa7c0509f4e.png&height=100" alt="callemall" title="グループにメッセージを送る簡単な方法">
  </a>
</p>

### もっとあります！

[私たちのサポーター](/discover-more/backers/)のリストを見て下さい。