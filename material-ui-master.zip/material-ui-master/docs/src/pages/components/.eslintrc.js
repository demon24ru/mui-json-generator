module.exports = {
  rules: {
    // useful for interactions feedback
    'no-alert': 'off',
    // not very friendly to prop forwarding
    'react/jsx-handler-names': 'off',
  },
};
