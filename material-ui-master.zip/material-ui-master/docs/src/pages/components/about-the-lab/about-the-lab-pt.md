# Sobre o lab

<p class="description">Este pacote hospeda os componentes da incubadora que ainda não estão prontos para mover para o núcleo (core).</p>

## Instalação

Instale o pacote no diretório do seu projeto com:

```sh
// usando npm
npm install @material-ui/lab

// usando yarn
yarn add @material-ui/lab
```

O lab tem uma dependência com o core componentes. Se você ainda não estiver usando Material-UI no seu projeto, você pode instalá-lo com:

```sh
// usando npm
npm install @material-ui/core

// usando yarn
yarn add @material-ui/core
```